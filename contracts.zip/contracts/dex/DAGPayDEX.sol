// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "../interfaces/IERC20.sol";

contract DAGPayDEX is IDEX {
    mapping(address => mapping(address => uint256)) public exchangeRates;
    address public owner;
    
    event TokensSwapped(
        address indexed user,
        address tokenIn,
        address tokenOut,
        uint256 amountIn,
        uint256 amountOut
    );
    
    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }
    
    constructor() {
        owner = msg.sender;
    }
    
    function setExchangeRate(
        address _tokenIn,
        address _tokenOut,
        uint256 _rate
    ) external onlyOwner {
        exchangeRates[_tokenIn][_tokenOut] = _rate;
    }
    
    function swapTokens(
        address _tokenIn,
        address _tokenOut,
        uint256 _amountIn,
        uint256 _minAmountOut
    ) external override returns (uint256) {
        require(_amountIn > 0, "Amount must be positive");
        require(exchangeRates[_tokenIn][_tokenOut] > 0, "Exchange rate not set");
        
        uint256 amountOut = (_amountIn * exchangeRates[_tokenIn][_tokenOut]) / 1e18;
        require(amountOut >= _minAmountOut, "Slippage too high");
        
        // Transfer tokens from user
        require(
            IERC20(_tokenIn).transferFrom(msg.sender, address(this), _amountIn),
            "Token transfer failed"
        );
        
        // Transfer output tokens to user
        require(
            IERC20(_tokenOut).transfer(msg.sender, amountOut),
            "Output token transfer failed"
        );
        
        emit TokensSwapped(msg.sender, _tokenIn, _tokenOut, _amountIn, amountOut);
        
        return amountOut;
    }
    
    function getExchangeRate(
        address _tokenIn,
        address _tokenOut
    ) external view override returns (uint256) {
        return exchangeRates[_tokenIn][_tokenOut];
    }
    
    // Emergency withdraw tokens (for owner only)
    function withdrawToken(address _token, uint256 _amount) external onlyOwner {
        IERC20(_token).transfer(owner, _amount);
    }
}