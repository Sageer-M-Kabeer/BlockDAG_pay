// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "../interfaces/IERC20.sol";

contract StakingPool {
    IERC20 public stakingToken;
    IERC20 public rewardToken;
    
    struct Stake {
        uint256 amount;
        uint256 stakeTime;
        uint256 lastRewardTime;
    }
    
    mapping(address => Stake) public stakes;
    uint256 public totalStaked;
    uint256 public rewardRate = 100; // 100 tokens per second per 1e18 staked
    
    event Staked(address indexed user, uint256 amount);
    event Unstaked(address indexed user, uint256 amount);
    event RewardClaimed(address indexed user, uint256 reward);
    
    constructor(address _stakingToken, address _rewardToken) {
        stakingToken = IERC20(_stakingToken);
        rewardToken = IERC20(_rewardToken);
    }
    
    function stake(uint256 _amount) external {
        require(_amount > 0, "Amount must be positive");
        
        Stake storage userStake = stakes[msg.sender];
        
        // Claim existing rewards first
        if (userStake.amount > 0) {
            _claimReward(msg.sender);
        }
        
        require(
            stakingToken.transferFrom(msg.sender, address(this), _amount),
            "Token transfer failed"
        );
        
        userStake.amount += _amount;
        userStake.stakeTime = block.timestamp;
        userStake.lastRewardTime = block.timestamp;
        
        totalStaked += _amount;
        
        emit Staked(msg.sender, _amount);
    }
    
    function unstake(uint256 _amount) external {
        Stake storage userStake = stakes[msg.sender];
        require(userStake.amount >= _amount, "Insufficient staked amount");
        
        _claimReward(msg.sender);
        
        userStake.amount -= _amount;
        totalStaked -= _amount;
        
        require(
            stakingToken.transfer(msg.sender, _amount),
            "Token transfer failed"
        );
        
        emit Unstaked(msg.sender, _amount);
    }
    
    function claimReward() external {
        _claimReward(msg.sender);
    }
    
    function _claimReward(address _user) internal {
        Stake storage userStake = stakes[_user];
        uint256 reward = calculateReward(_user);
        
        if (reward > 0) {
            userStake.lastRewardTime = block.timestamp;
            
            require(
                rewardToken.transfer(_user, reward),
                "Reward transfer failed"
            );
            
            emit RewardClaimed(_user, reward);
        }
    }
    
    function calculateReward(address _user) public view returns (uint256) {
        Stake memory userStake = stakes[_user];
        if (userStake.amount == 0) return 0;
        
        uint256 timeStaked = block.timestamp - userStake.lastRewardTime;
        return (userStake.amount * rewardRate * timeStaked) / 1e18;
    }
}