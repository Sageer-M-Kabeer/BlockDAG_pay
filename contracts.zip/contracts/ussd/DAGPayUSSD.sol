// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract DAGPayUSSD {
    // This contract handles OTP generation and verification for USSD and SMS payments.

    mapping(address => uint256) public otpCodes;
    mapping(address => uint256) public otpExpiry;

    event OTPGenerated(address indexed user, uint256 otp);
    OTPVerified(address indexed user, uint256 otp);

    function generateOTP() external {
        uint256 otp = uint256(keccak256(abi.encodePacked(block.timestamp, msg.sender))) % 1000000;
        otpCodes[msg.sender] = otp;
        otpExpiry[msg.sender] = block.timestamp + 5 minutes; // OTP valid for 5 minutes

        emit OTPGenerated(msg.sender, otp);
    }

    function verifyOTP(uint256 otp) external returns (bool) {
        require(otpCodes[msg.sender] == otp, "Invalid OTP");
        require(block.timestamp <= otpExpiry[msg.sender], "OTP expired");

        delete otpCodes[msg.sender];
        delete otpExpiry[msg.sender];

        emit OTPVerified(msg.sender, otp);
        return true;
    }
}