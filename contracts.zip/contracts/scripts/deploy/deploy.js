// deploy/01_deploy_tokens_and_payment.js
const { ethers } = require("hardhat");

async function main() {
  const [deployer] = await ethers.getSigners();
  
  console.log("Deploying tokens and payment system with account:", deployer.address);

  // Deploy Local Stablecoins
  const LocalStablecoin = await ethers.getContractFactory("LocalStablecoin");
  
  const usdStablecoin = await LocalStablecoin.deploy(
    "USDC Stablecoin",
    "USDC",
    "USD",
    deployer.address
  );
  await usdStablecoin.deployed();
  console.log("USD Stablecoin deployed to:", usdStablecoin.address);

  const eurStablecoin = await LocalStablecoin.deploy(
    "EURC Stablecoin",
    "EURC",
    "EUR",
    deployer.address
  );
  await eurStablecoin.deployed();
  console.log("EUR Stablecoin deployed to:", eurStablecoin.address);

  // Deploy DAGPay Token
  const DAGPayToken = await ethers.getContractFactory("DAGPayToken");
  const dagPayToken = await DAGPayToken.deploy(
    "DAGPay Token",
    "DAGP",
    deployer.address, // treasury
    deployer.address  // owner
  );
  await dagPayToken.deployed();
  console.log("DAGPay Token deployed to:", dagPayToken.address);

  // Deploy Payment Manager
  const PaymentManager = await ethers.getContractFactory("PaymentManager");
  const paymentManager = await PaymentManager.deploy(
    "0xDEXAddress", // Replace with actual DEX address
    deployer.address // fee collector
  );
  await paymentManager.deployed();
  console.log("PaymentManager deployed to:", paymentManager.address);

  // Add stablecoins to PaymentManager
  await paymentManager.addStablecoin("USD", usdStablecoin.address);
  await paymentManager.addStablecoin("EUR", eurStablecoin.address);
  console.log("Stablecoins added to PaymentManager");

  // Mint initial stablecoins to PaymentManager for testing
  await usdStablecoin.mint(paymentManager.address, ethers.utils.parseUnits("1000000", 6));
  await eurStablecoin.mint(paymentManager.address, ethers.utils.parseUnits("1000000", 6));
  console.log("Initial stablecoins minted to PaymentManager");

  console.log("\n=== Deployment Summary ===");
  console.log("USD Stablecoin:", usdStablecoin.address);
  console.log("EUR Stablecoin:", eurStablecoin.address);
  console.log("DAGPay Token:", dagPayToken.address);
  console.log("Payment Manager:", paymentManager.address);
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });