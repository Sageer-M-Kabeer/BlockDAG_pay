// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

/**
 * @title LocalStablecoin
 * @dev Local currency stablecoins for different regions (e.g., USDC, EURC, NGNR for Nigeria Naira)
 */
contract LocalStablecoin is ERC20, Ownable {
    // Currency code (e.g., "USD", "EUR", "NGN")
    string public currencyCode;
    
    // Minting controller (usually the DAGPay system)
    address public minter;
    
    event MinterUpdated(address indexed newMinter);
    event StablecoinMinted(address indexed to, uint256 amount);
    event StablecoinBurned(address indexed from, uint256 amount);
    
    modifier onlyMinter() {
        require(msg.sender == minter, "Only minter can call this");
        _;
    }
    
    constructor(
        string memory _name,
        string memory _symbol,
        string memory _currencyCode,
        address _initialOwner
    ) ERC20(_name, _symbol) Ownable(_initialOwner) {
        currencyCode = _currencyCode;
        minter = _initialOwner;
    }
    
    /**
     * @dev Mint new stablecoins (only by minter)
     */
    function mint(address _to, uint256 _amount) external onlyMinter {
        _mint(_to, _amount);
        emit StablecoinMinted(_to, _amount);
    }
    
    /**
     * @dev Burn stablecoins (only by minter or token holder)
     */
    function burn(address _from, uint256 _amount) external {
        require(
            msg.sender == _from || msg.sender == minter,
            "Not authorized to burn"
        );
        _burn(_from, _amount);
        emit StablecoinBurned(_from, _amount);
    }
    
    /**
     * @dev Update the minter address (only owner)
     */
    function setMinter(address _newMinter) external onlyOwner {
        require(_newMinter != address(0), "Invalid minter address");
        minter = _newMinter;
        emit MinterUpdated(_newMinter);
    }
    
    /**
     * @dev Override decimals for stablecoins (typically 6 for USDC-like, 18 for others)
     */
    function decimals() public pure override returns (uint8) {
        return 6;
    }
}