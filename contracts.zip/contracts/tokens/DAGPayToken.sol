// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

/**
 * @title DAGPayToken
 * @dev Utility token for the DAGPay ecosystem (governance, fees, rewards)
 */
contract DAGPayToken is ERC20, Ownable {
    uint256 public constant MAX_SUPPLY = 1_000_000_000 * 10**18; // 1 billion tokens
    
    // Tax configuration (can be turned on/off)
    uint256 public transactionTax = 200; // 2% in basis points (100 = 1%)
    address public treasury;
    bool public taxEnabled = false;
    
    // Excluded addresses from tax (DEX pools, staking contracts, etc.)
    mapping(address => bool) public isExcludedFromTax;
    
    event TaxUpdated(uint256 newTax);
    event TreasuryUpdated(address newTreasury);
    event TaxToggled(bool enabled);
    event ExcludedFromTax(address account, bool excluded);
    
    constructor(
        string memory _name,
        string memory _symbol,
        address _treasury,
        address _initialOwner
    ) ERC20(_name, _symbol) Ownable(_initialOwner) {
        treasury = _treasury;
        
        // Exclude treasury and owner from tax
        isExcludedFromTax[_treasury] = true;
        isExcludedFromTax[_initialOwner] = true;
        
        // Mint initial supply to treasury
        _mint(_treasury, MAX_SUPPLY / 2); // 500 million to treasury
        _mint(_initialOwner, MAX_SUPPLY / 4); // 250 million to owner
    }
    
    /**
     * @dev Override transfer to include tax logic
     */
    function _transfer(
        address from,
        address to,
        uint256 amount
    ) internal override {
        if (taxEnabled && !isExcludedFromTax[from] && !isExcludedFromTax[to]) {
            uint256 taxAmount = (amount * transactionTax) / 10000;
            uint256 transferAmount = amount - taxAmount;
            
            if (taxAmount > 0) {
                super._transfer(from, treasury, taxAmount);
            }
            
            super._transfer(from, to, transferAmount);
        } else {
            super._transfer(from, to, amount);
        }
    }
    
    /**
     * @dev Set transaction tax (only owner)
     */
    function setTransactionTax(uint256 _newTax) external onlyOwner {
        require(_newTax <= 500, "Tax too high"); // Max 5%
        transactionTax = _newTax;
        emit TaxUpdated(_newTax);
    }
    
    /**
     * @dev Set treasury address (only owner)
     */
    function setTreasury(address _newTreasury) external onlyOwner {
        require(_newTreasury != address(0), "Invalid treasury");
        treasury = _newTreasury;
        emit TreasuryUpdated(_newTreasury);
    }
    
    /**
     * @dev Toggle tax on/off (only owner)
     */
    function toggleTax() external onlyOwner {
        taxEnabled = !taxEnabled;
        emit TaxToggled(taxEnabled);
    }
    
    /**
     * @dev Exclude/include address from tax (only owner)
     */
    function setExcludedFromTax(address _account, bool _excluded) external onlyOwner {
        isExcludedFromTax[_account] = _excluded;
        emit ExcludedFromTax(_account, _excluded);
    }
    
    /**
     * @dev Mint additional tokens (only owner, up to max supply)
     */
    function mint(address _to, uint256 _amount) external onlyOwner {
        require(totalSupply() + _amount <= MAX_SUPPLY, "Exceeds max supply");
        _mint(_to, _amount);
    }
}