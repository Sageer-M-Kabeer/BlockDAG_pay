// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "../interfaces/IERC20.sol";

contract LendingPool {
    IERC20 public collateralToken;
    IERC20 public stablecoin;
    
    uint256 public collateralRatio = 150; // 150% minimum collateralization
    uint256 public interestRate = 5; // 5% annual interest
    
    struct Loan {
        uint256 collateralAmount;
        uint256 borrowAmount;
        uint256 borrowTime;
        uint256 interestAccrued;
    }
    
    mapping(address => Loan) public loans;
    
    event LoanCreated(address indexed user, uint256 collateral, uint256 borrowAmount);
    event LoanRepaid(address indexed user, uint256 amount);
    event CollateralAdded(address indexed user, uint256 amount);
    
    constructor(address _collateralToken, address _stablecoin) {
        collateralToken = IERC20(_collateralToken);
        stablecoin = IERC20(_stablecoin);
    }
    
    function createLoan(uint256 _collateralAmount, uint256 _borrowAmount) external {
        require(_collateralAmount > 0, "Collateral must be positive");
        require(_borrowAmount > 0, "Borrow amount must be positive");
        
        // Check collateral ratio
        require(
            (_collateralAmount * 100) >= (_borrowAmount * collateralRatio),
            "Insufficient collateral"
        );
        
        require(
            collateralToken.transferFrom(msg.sender, address(this), _collateralAmount),
            "Collateral transfer failed"
        );
        
        Loan storage loan = loans[msg.sender];
        loan.collateralAmount += _collateralAmount;
        loan.borrowAmount += _borrowAmount;
        loan.borrowTime = block.timestamp;
        
        require(
            stablecoin.transfer(msg.sender, _borrowAmount),
            "Stablecoin transfer failed"
        );
        
        emit LoanCreated(msg.sender, _collateralAmount, _borrowAmount);
    }
    
    function repayLoan(uint256 _repayAmount) external {
        Loan storage loan = loans[msg.sender];
        require(loan.borrowAmount > 0, "No active loan");
        
        uint256 interest = calculateInterest(msg.sender);
        uint256 totalDue = loan.borrowAmount + interest;
        
        require(_repayAmount <= totalDue, "Repay amount exceeds debt");
        
        require(
            stablecoin.transferFrom(msg.sender, address(this), _repayAmount),
            "Repayment transfer failed"
        );
        
        if (_repayAmount >= totalDue) {
            // Full repayment - return collateral
            uint256 collateralToReturn = loan.collateralAmount;
            loan.collateralAmount = 0;
            loan.borrowAmount = 0;
            loan.interestAccrued = 0;
            
            require(
                collateralToken.transfer(msg.sender, collateralToReturn),
                "Collateral return failed"
            );
        } else {
            // Partial repayment
            if (_repayAmount > interest) {
                loan.borrowAmount -= (_repayAmount - interest);
            }
            loan.interestAccrued = 0;
            loan.borrowTime = block.timestamp; // Reset interest calculation
        }
        
        emit LoanRepaid(msg.sender, _repayAmount);
    }
    
    function addCollateral(uint256 _amount) external {
        require(_amount > 0, "Amount must be positive");
        
        require(
            collateralToken.transferFrom(msg.sender, address(this), _amount),
            "Collateral transfer failed"
        );
        
        loans[msg.sender].collateralAmount += _amount;
        
        emit CollateralAdded(msg.sender, _amount);
    }
    
    function calculateInterest(address _user) public view returns (uint256) {
        Loan memory loan = loans[_user];
        if (loan.borrowAmount == 0) return 0;
        
        uint256 timeElapsed = block.timestamp - loan.borrowTime;
        uint256 annualInterest = (loan.borrowAmount * interestRate) / 100;
        
        return (annualInterest * timeElapsed) / 365 days;
    }
    
    function getCollateralizationRatio(address _user) public view returns (uint256) {
        Loan memory loan = loans[_user];
        if (loan.borrowAmount == 0) return 0;
        
        return (loan.collateralAmount * 100) / loan.borrowAmount;
    }
}