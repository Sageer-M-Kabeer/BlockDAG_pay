// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/**
 * @title OTPManager
 * @dev Manages One-Time Passwords for OTP and USSD payments
 */
contract OTPManager {
    struct OTPRequest {
        bytes32 otpHash;
        uint256 amount;
        address user;
        address merchant;
        uint256 expiry;
        bool used;
        string paymentType; // "OTP" or "USSD"
    }
    
    // USSD session management
    struct USSDSession {
        address user;
        string phoneNumber;
        uint256 created;
        bool active;
    }
    
    mapping(bytes32 => OTPRequest) public otpRequests;
    mapping(string => USSDSession) public ussdSessions; // phoneNumber -> session
    mapping(address => uint256) public userNonce;
    
    uint256 public constant OTP_EXPIRY_TIME = 10 minutes;
    uint256 public constant USSD_SESSION_EXPIRY = 5 minutes;
    
    event OTPCreated(
        bytes32 indexed otpHash, 
        address user, 
        address merchant, 
        uint256 amount,
        string paymentType
    );
    event OTPUsed(bytes32 indexed otpHash, address user);
    event USSDSessionCreated(string phoneNumber, address user);
    event USSDSessionCompleted(string phoneNumber, address user);
    
    /**
     * @dev Create OTP payment request
     */
    function createOTPRequest(
        bytes32 _otpHash,
        uint256 _amount,
        address _user,
        address _merchant,
        string memory _paymentType
    ) external {
        require(_amount > 0, "Amount must be positive");
        require(_user != address(0), "Invalid user");
        
        OTPRequest storage request = otpRequests[_otpHash];
        request.otpHash = _otpHash;
        request.amount = _amount;
        request.user = _user;
        request.merchant = _merchant;
        request.expiry = block.timestamp + OTP_EXPIRY_TIME;
        request.used = false;
        request.paymentType = _paymentType;
        
        emit OTPCreated(_otpHash, _user, _merchant, _amount, _paymentType);
    }
    
    /**
     * @dev Create USSD session for feature phone users
     */
    function createUSSDSession(
        string memory _phoneNumber,
        address _user
    ) external returns (bytes32) {
        require(_user != address(0), "Invalid user");
        
        USSDSession storage session = ussdSessions[_phoneNumber];
        session.user = _user;
        session.phoneNumber = _phoneNumber;
        session.created = block.timestamp;
        session.active = true;
        
        // Generate OTP for this session
        uint256 nonce = userNonce[_user]++;
        bytes32 otpHash = keccak256(abi.encodePacked(_phoneNumber, _user, nonce, block.timestamp));
        
        emit USSDSessionCreated(_phoneNumber, _user);
        
        return otpHash;
    }
    
    /**
     * @dev Verify and consume OTP
     */
    function verifyAndConsumeOTP(
        bytes32 _otpHash,
        address _user
    ) external returns (OTPRequest memory) {
        OTPRequest storage request = otpRequests[_otpHash];
        
        require(request.user == _user, "OTP user mismatch");
        require(!request.used, "OTP already used");
        require(block.timestamp <= request.expiry, "OTP expired");
        require(request.amount > 0, "Invalid OTP request");
        
        request.used = true;
        
        // If USSD session, mark as completed
        if (keccak256(abi.encodePacked(request.paymentType)) == keccak256(abi.encodePacked("USSD"))) {
            _completeUSSDSession(request.user);
        }
        
        emit OTPUsed(_otpHash, _user);
        
        return request;
    }
    
    /**
     * @dev Complete USSD session
     */
    function _completeUSSDSession(address _user) internal {
        // Find and deactivate USSD session for this user
        // Note: In production, you'd want a better mapping for this
        emit USSDSessionCompleted("", _user); // Phone number would be tracked off-chain
    }
    
    /**
     * @dev Verify USSD session is active
     */
    function verifyUSSDSession(
        string memory _phoneNumber,
        address _user
    ) external view returns (bool) {
        USSDSession memory session = ussdSessions[_phoneNumber];
        return (
            session.active &&
            session.user == _user &&
            block.timestamp <= session.created + USSD_SESSION_EXPIRY
        );
    }
    
    /**
     * @dev Generate OTP hash (off-chain helper)
     */
    function generateOTPHash(
        string memory _otp,
        address _user
    ) external pure returns (bytes32) {
        return keccak256(abi.encodePacked(_otp, _user));
    }
    
    /**
     * @dev Generate USSD OTP hash
     */
    function generateUSSDHash(
        string memory _phoneNumber,
        address _user,
        uint256 _nonce
    ) external view returns (bytes32) {
        return keccak256(abi.encodePacked(_phoneNumber, _user, _nonce, block.timestamp));
    }
}