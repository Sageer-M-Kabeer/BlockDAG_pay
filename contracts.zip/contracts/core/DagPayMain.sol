// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "../interfaces/IERC20.sol";
import "../interfaces/IDEX.sol";
import "./OTPManager.sol";

contract DAGPayMain {
    address public owner;
    IDEX public dex;
    OTPManager public otpManager;
    
    // Payment events
    event PaymentCompleted(
        address indexed user,
        address indexed merchant,
        address tokenIn,
        address stablecoinOut,
        uint256 amountIn,
        uint256 amountOut,
        uint256 timestamp
    );
    
    event OTPPaymentInitiated(
        address indexed user,
        bytes32 indexed otpHash,
        uint256 amount,
        address merchant
    );
    
    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }
    
    constructor(address _dexAddress) {
        owner = msg.sender;
        dex = IDEX(_dexAddress);
        otpManager = new OTPManager();
    }
    
    /**
     * @dev Process QR code payment with automatic DEX swap
     */
    function processQRPayment(
        address _merchant,
        address _tokenIn,
        address _stablecoinOut,
        uint256 _amountIn,
        uint256 _minAmountOut
    ) external returns (bool) {
        require(_amountIn > 0, "Amount must be positive");
        require(_merchant != address(0), "Invalid merchant");
        
        // Transfer tokens from user to this contract
        require(
            IERC20(_tokenIn).transferFrom(msg.sender, address(this), _amountIn),
            "Token transfer failed"
        );
        
        // Approve DEX to spend tokens
        IERC20(_tokenIn).approve(address(dex), _amountIn);
        
        // Execute swap
        uint256 amountOut = dex.swapTokens(
            _tokenIn,
            _stablecoinOut,
            _amountIn,
            _minAmountOut
        );
        
        // Transfer stablecoin to merchant
        require(
            IERC20(_stablecoinOut).transfer(_merchant, amountOut),
            "Stablecoin transfer failed"
        );
        
        emit PaymentCompleted(
            msg.sender,
            _merchant,
            _tokenIn,
            _stablecoinOut,
            _amountIn,
            amountOut,
            block.timestamp
        );
        
        return true;
    }
    
    /**
     * @dev Initiate OTP payment (first step - merchant submits OTP)
     */
    function initiateOTPPayment(
        bytes32 _otpHash,
        uint256 _amount,
        address _user
    ) external returns (bool) {
        otpManager.createOTPRequest(_otpHash, _amount, _user, msg.sender);
        
        emit OTPPaymentInitiated(
            _user,
            _otpHash,
            _amount,
            msg.sender
        );
        
        return true;
    }
    
    /**
     * @dev Complete OTP payment (second step - user approves)
     */
    function completeOTPPayment(
        string memory _otp,
        address _tokenIn,
        address _stablecoinOut,
        uint256 _minAmountOut
    ) external returns (bool) {
        OTPManager.OTPRequest memory request = otpManager.verifyAndConsumeOTP(_otp, msg.sender);
        
        // Process the payment with DEX swap
        require(
            IERC20(_tokenIn).transferFrom(msg.sender, address(this), request.amount),
            "Token transfer failed"
        );
        
        IERC20(_tokenIn).approve(address(dex), request.amount);
        
        uint256 amountOut = dex.swapTokens(
            _tokenIn,
            _stablecoinOut,
            request.amount,
            _minAmountOut
        );
        
        require(
            IERC20(_stablecoinOut).transfer(request.merchant, amountOut),
            "Stablecoin transfer failed"
        );
        
        emit PaymentCompleted(
            msg.sender,
            request.merchant,
            _tokenIn,
            _stablecoinOut,
            request.amount,
            amountOut,
            block.timestamp
        );
        
        return true;
    }
    
    function setDEX(address _newDEX) external onlyOwner {
        dex = IDEX(_newDEX);
    }
}