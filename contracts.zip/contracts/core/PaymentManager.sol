// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "../interfaces/IERC20.sol";
import "../interfaces/IDEX.sol";
import "./OTPManager.sol";

/**
 * @title PaymentManager
 * @dev Central contract managing all payment flows and settlement
 */
contract PaymentManager {
    address public owner;
    IDEX public dex;
    OTPManager public otpManager;
    
    // Supported stablecoins by currency code
    mapping(string => address) public stablecoins;
    
    // Merchant registry
    mapping(address => MerchantInfo) public merchants;
    
    // Fee configuration
    uint256 public platformFee = 50; // 0.5% in basis points
    address public feeCollector;
    
    // Payment statistics
    uint256 public totalTransactions;
    uint256 public totalVolume;
    
    struct MerchantInfo {
        bool registered;
        string currencyCode; // Preferred settlement currency
        string businessName;
        uint256 totalSales;
        uint256 totalFees;
    }
    
    struct PaymentRequest {
        address user;
        address merchant;
        address tokenIn;
        string currencyOut;
        uint256 amountIn;
        uint256 minAmountOut;
        uint256 timestamp;
        bool completed;
    }
    
    // Events
    event MerchantRegistered(address indexed merchant, string businessName, string currencyCode);
    event PaymentInitiated(
        uint256 indexed paymentId,
        address indexed user,
        address indexed merchant,
        address tokenIn,
        string currencyOut,
        uint256 amountIn
    );
    event PaymentCompleted(
        uint256 indexed paymentId,
        address tokenIn,
        address stablecoinOut,
        uint256 amountIn,
        uint256 amountOut,
        uint256 feeAmount
    );
    event PaymentFailed(uint256 indexed paymentId, string reason);
    event StablecoinAdded(string currencyCode, address tokenAddress);
    event PlatformFeeUpdated(uint256 newFee);
    
    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }
    
    modifier onlyRegisteredMerchant() {
        require(merchants[msg.sender].registered, "Merchant not registered");
        _;
    }
    
    constructor(address _dexAddress, address _feeCollector) {
        owner = msg.sender;
        dex = IDEX(_dexAddress);
        otpManager = new OTPManager();
        feeCollector = _feeCollector;
    }
    
    /**
     * @dev Register a new merchant
     */
    function registerMerchant(
        string memory _businessName,
        string memory _currencyCode
    ) external {
        require(!merchants[msg.sender].registered, "Already registered");
        require(stablecoins[_currencyCode] != address(0), "Currency not supported");
        
        merchants[msg.sender] = MerchantInfo({
            registered: true,
            currencyCode: _currencyCode,
            businessName: _businessName,
            totalSales: 0,
            totalFees: 0
        });
        
        emit MerchantRegistered(msg.sender, _businessName, _currencyCode);
    }
    
    /**
     * @dev Process QR code payment
     */
    function processQRPayment(
        address _merchant,
        address _tokenIn,
        uint256 _amountIn,
        uint256 _minAmountOut
    ) external returns (uint256) {
        require(_amountIn > 0, "Amount must be positive");
        require(merchants[_merchant].registered, "Merchant not registered");
        
        MerchantInfo storage merchant = merchants[_merchant];
        address stablecoinOut = stablecoins[merchant.currencyCode];
        require(stablecoinOut != address(0), "Stablecoin not found");
        
        // Create payment request
        uint256 paymentId = totalTransactions + 1;
        
        // Transfer tokens from user
        require(
            IERC20(_tokenIn).transferFrom(msg.sender, address(this), _amountIn),
            "Token transfer failed"
        );
        
        // Process payment with DEX swap
        (bool success, uint256 amountOut, uint256 feeAmount) = _processPayment(
            paymentId,
            msg.sender,
            _merchant,
            _tokenIn,
            stablecoinOut,
            _amountIn,
            _minAmountOut
        );
        
        if (success) {
            merchant.totalSales += amountOut;
            merchant.totalFees += feeAmount;
            totalVolume += _amountIn;
            
            emit PaymentInitiated(
                paymentId,
                msg.sender,
                _merchant,
                _tokenIn,
                merchant.currencyCode,
                _amountIn
            );
            
            return paymentId;
        } else {
            // Refund user if payment fails
            IERC20(_tokenIn).transfer(msg.sender, _amountIn);
            emit PaymentFailed(paymentId, "DEX swap failed");
            revert("Payment processing failed");
        }
    }
    
    /**
     * @dev Process USSD/SMS payment (for feature phones)
     */
    function processUSSDPayment(
        bytes32 _otpHash,
        address _user,
        address _tokenIn,
        uint256 _minAmountOut
    ) external onlyRegisteredMerchant returns (uint256) {
        OTPManager.OTPRequest memory request = otpManager.verifyAndConsumeOTP(
            _otpHash,
            _user
        );
        
        MerchantInfo storage merchant = merchants[msg.sender];
        address stablecoinOut = stablecoins[merchant.currencyCode];
        
        uint256 paymentId = totalTransactions + 1;
        
        // Transfer tokens from user (pre-approved in USSD flow)
        require(
            IERC20(_tokenIn).transferFrom(_user, address(this), request.amount),
            "Token transfer failed"
        );
        
        (bool success, uint256 amountOut, uint256 feeAmount) = _processPayment(
            paymentId,
            _user,
            msg.sender,
            _tokenIn,
            stablecoinOut,
            request.amount,
            _minAmountOut
        );
        
        if (success) {
            merchant.totalSales += amountOut;
            merchant.totalFees += feeAmount;
            totalVolume += request.amount;
            
            emit PaymentInitiated(
                paymentId,
                _user,
                msg.sender,
                _tokenIn,
                merchant.currencyCode,
                request.amount
            );
            
            return paymentId;
        } else {
            IERC20(_tokenIn).transfer(_user, request.amount);
            emit PaymentFailed(paymentId, "DEX swap failed");
            revert("USSD payment failed");
        }
    }
    
    /**
     * @dev Internal payment processing with DEX swap
     */
    function _processPayment(
        uint256 _paymentId,
        address _user,
        address _merchant,
        address _tokenIn,
        address _stablecoinOut,
        uint256 _amountIn,
        uint256 _minAmountOut
    ) internal returns (bool, uint256, uint256) {
        // Approve DEX to spend tokens
        IERC20(_tokenIn).approve(address(dex), _amountIn);
        
        // Execute swap
        uint256 amountOut = dex.swapTokens(
            _tokenIn,
            _stablecoinOut,
            _amountIn,
            _minAmountOut
        );
        
        if (amountOut == 0) {
            return (false, 0, 0);
        }
        
        // Calculate and deduct platform fee
        uint256 feeAmount = (amountOut * platformFee) / 10000;
        uint256 merchantAmount = amountOut - feeAmount;
        
        // Transfer to merchant and fee collector
        require(
            IERC20(_stablecoinOut).transfer(_merchant, merchantAmount),
            "Merchant transfer failed"
        );
        
        if (feeAmount > 0) {
            require(
                IERC20(_stablecoinOut).transfer(feeCollector, feeAmount),
                "Fee transfer failed"
            );
        }
        
        totalTransactions++;
        
        emit PaymentCompleted(
            _paymentId,
            _tokenIn,
            _stablecoinOut,
            _amountIn,
            merchantAmount,
            feeAmount
        );
        
        return (true, merchantAmount, feeAmount);
    }
    
    /**
     * @dev Add supported stablecoin
     */
    function addStablecoin(
        string memory _currencyCode,
        address _tokenAddress
    ) external onlyOwner {
        require(_tokenAddress != address(0), "Invalid token address");
        stablecoins[_currencyCode] = _tokenAddress;
        emit StablecoinAdded(_currencyCode, _tokenAddress);
    }
    
    /**
     * @dev Update platform fee
     */
    function setPlatformFee(uint256 _newFee) external onlyOwner {
        require(_newFee <= 200, "Fee too high"); // Max 2%
        platformFee = _newFee;
        emit PlatformFeeUpdated(_newFee);
    }
    
    /**
     * @dev Update fee collector
     */
    function setFeeCollector(address _newCollector) external onlyOwner {
        require(_newCollector != address(0), "Invalid address");
        feeCollector = _newCollector;
    }
    
    /**
     * @dev Get merchant information
     */
    function getMerchantInfo(address _merchant) external view returns (MerchantInfo memory) {
        return merchants[_merchant];
    }
    
    /**
     * @dev Get supported stablecoin for currency
     */
    function getStablecoin(string memory _currencyCode) external view returns (address) {
        return stablecoins[_currencyCode];
    }
    
    /**
     * @dev Get payment statistics
     */
    function getStats() external view returns (uint256 transactions, uint256 volume) {
        return (totalTransactions, totalVolume);
    }
}