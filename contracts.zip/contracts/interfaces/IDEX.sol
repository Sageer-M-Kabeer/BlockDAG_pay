// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

interface IDEX {
    function swapTokens(
        address tokenIn,
        address tokenOut,
        uint256 amountIn,
        uint256 minAmountOut
    ) external returns (uint256 amountOut);
    
    function getExchangeRate(
        address tokenIn, 
        address tokenOut
    ) external view returns (uint256 rate);
}